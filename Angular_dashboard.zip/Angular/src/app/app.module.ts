import { ViewsModule } from './views/views.module';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TopHeaderComponent } from './basic/top-header/top-header.component';
import { SidebarMenuComponent } from './basic/sidebar-menu/sidebar-menu.component';
import { ChatComponent } from './basic/chat/chat.component';
import { Demo1Component } from './test/demo1/demo1.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    TopHeaderComponent,
    SidebarMenuComponent,
    ChatComponent,
    Demo1Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ViewsModule,
    FormsModule,
    HttpClientModule

  ],
  providers: [

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
