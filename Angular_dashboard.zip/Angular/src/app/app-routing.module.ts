import { DatatableComponent } from './views/dashboard/datatable/datatable.component';
import { Demo1Component } from './test/demo1/demo1.component';
import { HomepageComponent } from './views/dashboard/homepage/homepage.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  // Dashboard homepage links
  { path: 'homepage', component: HomepageComponent },
  { path: 'demo1', component: Demo1Component },
  { path: 'datatable', component: DatatableComponent },

  // Mailbox dropdown page links

  // Direct page open
  { path: '', redirectTo: '/homepage', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
