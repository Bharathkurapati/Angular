import { HomepageComponent } from './dashboard/homepage/homepage.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DatatableComponent } from './dashboard/datatable/datatable.component';


import { DataTablesModule } from 'angular-datatables';

@NgModule({
  declarations: [
    HomepageComponent,
    DatatableComponent,
  ],
  imports: [
    CommonModule,
    DataTablesModule
  ]
})
export class ViewsModule { }
