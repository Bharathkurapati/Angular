import { Demo1 } from './demo1';

describe('Demo1', () => {
  it('should create an instance', () => {
    expect(new Demo1().toBeTruthy();
  });
});
