import { Demo1Service } from './../demo1.service';
import { Component, OnInit } from '@angular/core';
import { Demo1 } from '../demo1';

@Component({
  selector: 'app-demo1',
  templateUrl: './demo1.component.html',
  styleUrls: ['./demo1.component.css']
})
export class Demo1Component implements OnInit {
  ngOnInit(): void {
  }
  topics = ['Angular', 'React', 'Javascript'];
  topicHasError = true;
  submitted = false;

  demo1Model = new Demo1('Bharath', 'Bharath@gmail.com', 9494161584, 'default', 'morning', true);

  constructor(private _dem01Service: Demo1Service) { }

  validateTopic(value: string) {
    if (value === 'default') {
      this.topicHasError = true;
    } else {
      this.topicHasError = false;
    }
  }


  onSubmit() {
    // console.log(this.demo1Model);
    this.submitted = true;
    this._dem01Service.enroll(this.demo1Model)
      .subscribe(
        data => console.log('Success!', data),
        error => console.error('Error!', error)
      )
  }
}
