

////////////////////////// Sidebar menu //////////////////////////////

jQuery(function ($) {

  $(".sidebar-dropdown > a").click(function () {
    $(".sidebar-submenu").slideUp(200);

    if (
      $(this)
        .parent()
        .hasClass("active")
    ) {
      $(".sidebar-dropdown").removeClass("active");
      $(this)
        .parent()
        .removeClass("active");
    } else {
      $(".sidebar-dropdown").removeClass("active");
      $(this)
        .next(".sidebar-submenu")
        .slideDown(200);
      $(this)
        .parent()
        .addClass("active");
    }
  });

  // $("#close-sidebar").click(function() {
  //   $(".page-wrapper").removeClass("toggled");
  // });
  // $("#show-sidebar").click(function() {
  //   $(".page-wrapper").addClass("toggled");
  // });


  $(document).ready(function () {
    $('#show-sidebar').on('click', function () {
      $('#sidebar').toggleClass('active');
    });
  });

});


////////////////////////// close chat //////////////////////////////

$(document).ready(function () {
  $(".close-chat").click(function () {
    $(".chat-box-list").toggle(500);
  });

  setTimeout(function () {
    $('.chat-box-list').toggle('close');
  }, 3000);
});



////////////////////////// Calendar //////////////////////////////


// document.addEventListener('DOMContentLoaded', function () {

//   var containerEl = document.getElementById('external-events-list');
//   new FullCalendar.Draggable(containerEl, {
//     itemSelector: '.fc-event',
//     eventData: function (eventEl) {
//       return {
//         title: eventEl.innerText.trim()
//       }
//     }
//   });

//// the individual way to do it
// var containerEl = document.getElementById('external-events-list');
// var eventEls = Array.prototype.slice.call(
//   containerEl.querySelectorAll('.fc-event')
// );
// eventEls.forEach(function(eventEl) {
//   new FullCalendar.Draggable(eventEl, {
//     eventData: {
//       title: eventEl.innerText.trim(),
//     }
//   });
// });

/* initialize the calendar
-----------------------------------------------------------------*/

// var calendarEl = document.getElementById('calendar');
// var calendar = new FullCalendar.Calendar(calendarEl, {
//   headerToolbar: {
//     left: 'prev,next today',
//     center: 'title',
//     right: 'dayGridMonth,timeGridWeek,timeGridDay'
//   },
//   editable: true,
//   droppable: true,
//   drop: function (arg) {

//     if (document.getElementById('drop-remove').checked) {
//       arg.draggedEl.parentNode.removeChild(arg.draggedEl);
//     }
//   }
// });
// calendar.render();

// });



////////////////////////// full-screnn window //////////////////////////////

// $(function () {

//   $('body .requestfullscreen').click(function () {
//     $('body').fullscreen();
//     return false;
//   });
//   $('body .exitfullscreen').click(function () {
//     $.fullscreen.exit();
//     return false;
//   });
//   $(document).bind('fscreenchange', function (e, state, elem) {
//     if ($.fullscreen.isFullScreen()) {
//       $('body .requestfullscreen').hide();
//       $('body .exitfullscreen').show();
//     } else {
//       $('body .requestfullscreen').show();
//       $('body .exitfullscreen').hide();
//     }
//   });
// });


/////////////////////// Student Score tab //////////////////////////////

// $(function () {
//   $("#student-score li:first-child a").tab("show");
// });







////////////////////////// js tree  //////////////////////////////
// $(function () {
//   $("#jstree").jstree();
//   $("#jstree").on("changed.jstree", function (e, data) {
//     console.log(data.selected);
//   });
//   $("button").on("click", function () {
//     $("#jstree").jstree(true).select_node("child_node_1");
//     $("#jstree").jstree("select_node", "child_node_1");
//     $.jstree.reference("#jstree").select_node("child_node_1");
//   });
// });


////////////////////////// Switches  //////////////////////////////
// $(function () {
//   $('.checkall').checkall();
// });





////////////////////////// print window //////////////////////////////

function printDiv(printableArea) {
  var printContents = document.getElementById(printableArea).innerHTML;
  var originalContents = document.body.innerHTML;

  document.body.innerHTML = printContents;
  window.print();
  document.body.innerHTML = originalContents;
}
